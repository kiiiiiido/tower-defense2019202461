#include "menu.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>


Menu::Menu(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(800,450);
}


void Menu::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pixmap(":/menu.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}
