#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>
#include"mybutton.h"
#include"menu.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setFixedSize(800, 450);
    MyButton * btn=new MyButton(":/array2.png");
    btn->setParent(this);
    btn->move(600,265);
    Menu * scene = new Menu;
    connect(btn,&QPushButton::clicked,this,[=](){
        this->close();
        scene->show();
    });
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pixmap(":/start.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}















