#ifndef TOWER_H
#define TOWER_H
#include <QPoint>
#include <QSize>
#include <QPixmap>
#include <QObject>
#include"route.h"

class QPainter;
class MainWindow;
class QTimer;
class route;
class Enemy;

#include <QObject>

class Tower : public QObject
{
    Q_OBJECT
public:
    Tower(QPoint pos,route *game,const QPixmap &sprite = QPixmap(":/attacter.png"),
          int attackRange = 100,int damage=10);
     ~Tower();

    virtual void draw(QPainter *painter) const;
    void CheckEnemyInRange();
    void EnemyKilled();
    void attack();
    void ChooseEnemyForAttack(Enemy *enemy);
    void DamageEnemy();
    void EnemyOutOfRange();

protected slots:
    virtual void shootWeapon();

protected:
    bool			m_attacking;
    qreal			m_rotationSprite;

    Enemy *			m_chooseEnemy;
    route *        m_game;
    QTimer *		m_fireRateTimer;

    int				m_attackRange;
    int				m_damage;
    int				m_fireRate;

    const QPoint	m_pos;
    const QPixmap	m_sprite;

    static const QSize ms_fixedSize;
};




#endif // TOWER_H


