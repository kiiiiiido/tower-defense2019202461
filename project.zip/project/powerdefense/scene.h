#ifndef SCENE_H
#define SCENE_H


class scene
{
public:
    scene();
};

#endif // SCENE_H
