#ifndef ROUTE_H
#define ROUTE_H

#include <QMainWindow>
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>

class route : public QMainWindow
{
    Q_OBJECT
public:
    explicit route(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);

signals:
    void routeBack();

};

#endif // ROUTE_H
