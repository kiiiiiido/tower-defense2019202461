#ifndef SET_H
#define SET_H

#include <QMainWindow>
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>


class set : public QMainWindow
{
    Q_OBJECT
public:
    explicit set(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);


signals:
    void setBack();
};

#endif // SET_H
