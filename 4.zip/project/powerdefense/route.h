#ifndef ROUTE_H
#define ROUTE_H

#include <QMainWindow>
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>
#include"towerposition.h"
#include"tower.h"

class route : public QMainWindow
{
    Q_OBJECT
public:
    explicit route(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);

private:
    void loadTowerPositions();


signals:
    void routeBack();


};

#endif // ROUTE_H
