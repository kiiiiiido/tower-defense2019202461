#include "route.h"
#include"menu.h"
#include"tower.h"
#include"towerposition.h"
#include "ui_mainwindow.h"
#include"mybutton.h"
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>

route::route(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(960,540);

     loadTowerPositions();

    MyButton * back_btn=new MyButton(":/compass.png");
    back_btn->setParent(this);
    back_btn->move(800,40);
    connect(back_btn,&MyButton::clicked,this,[=](){
        emit routeBack();
    });
}

void route::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pixmap(":/withTower.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);


}


void route::loadTowerPositions()
{
    QPoint pos[] =
    {
        QPoint(65, 220),

    };
    int len	= sizeof(pos) / sizeof(pos[0]);


}


