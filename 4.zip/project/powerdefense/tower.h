#ifndef TOWER_H
#define TOWER_H
#include <QPoint>
#include <QSize>
#include <QPixmap>
#include <QObject>
#include"route.h"

class QPainter;
class MainWindow;
class QTimer;
class route;

#include <QObject>

class Tower : public QObject
{
    Q_OBJECT
public:
    Tower(QPoint pos,route *game,const QPixmap &sprite = QPixmap(":/attacter.png"),
          int attackRange = 100,int damage=10,int fireRate=100);

     ~Tower();

    virtual void draw(QPainter *painter) const;


protected:
    bool			m_attacking;
    qreal			m_rotationSprite;

    route *        m_game;
    QTimer *		m_rateTimer;

    int				m_attackRange;
    int				m_damage;
    int				m_fireRate;

    const QPoint	m_pos;
    const QPixmap	m_sprite;

    static const QSize ms_fixedSize;
};




#endif // TOWER_H


