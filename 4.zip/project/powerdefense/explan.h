#ifndef EXPLAN_H
#define EXPLAN_H

#include <QMainWindow>
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>

class explan : public QMainWindow
{
    Q_OBJECT
public:
    explicit explan(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);

signals:
    void explanBack();
};

#endif // EXPLAN_H
