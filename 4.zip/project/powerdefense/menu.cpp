#include "menu.h"
#include "mainwindow.h"
#include"set.h"
#include"route.h"
#include"explan.h"
#include "ui_mainwindow.h"
#include"mybutton.h"
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>


Menu::Menu(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(960,540);

   //set
    MyButton * btn_set=new MyButton(":/button_set.jpg");
    btn_set->setParent(this);
    btn_set->move(270,20);
    set * scene2 = new set;
    connect(btn_set,&QPushButton::clicked,this,[=](){
        this->hide();
        scene2->show();
    });
    connect(scene2,&set::setBack,this,[=](){
        scene2->hide();
        this->show();
    });

    //explan
    MyButton * btn_explan=new MyButton(":/button_explan.jpg");
    btn_explan->setParent(this);
    btn_explan->move(20,20);
    explan * scene3 = new explan;
    connect(btn_explan,&QPushButton::clicked,this,[=](){
        this->hide();
        scene3->show();
    });
    connect(scene3,&explan::explanBack,this,[=](){
        scene3->hide();
        this->show();
    });

    //route
    MyButton * btn_route=new MyButton(":/button_enter.jpg");
    btn_route->setParent(this);
    btn_route->move(530,20);
    route * scene4 = new route;
    connect(btn_route,&QPushButton::clicked,this,[=](){
        this->hide();
        scene4->show();
    });
    connect(scene4,&route::routeBack,this,[=](){
        scene4->hide();
        this->show();
    });

}



void Menu::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pixmap(":/sub.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}
