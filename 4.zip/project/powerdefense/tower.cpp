#include "tower.h"
#include "mainwindow.h"
#include"route.h"
#include <QPainter>
#include <QColor>
#include <QTimer>
#include <QVector2D>
#include <QtMath>


const QSize Tower::ms_fixedSize(65, 65);

Tower::Tower(QPoint pos, route *game, const QPixmap &sprite, int attackRange, int damage,int fireRate)
    : m_attacking(false)
    , m_rotationSprite(0.0)
    , m_game(game)
    , m_pos(pos)
    , m_sprite(sprite)
{
    m_rateTimer = new QTimer(this);
    connect(m_rateTimer, SIGNAL(timeout()), this, SLOT(shootWeapon()));
}

Tower::~Tower()
{
    delete m_rateTimer;
    m_rateTimer = nullptr;
}



void Tower::draw(QPainter *painter) const
{
    painter->save();
    painter->setPen(Qt::white);
    painter->drawEllipse(m_pos, m_attackRange, m_attackRange);
    static const QPoint offsetPoint(-ms_fixedSize.width() / 2, -ms_fixedSize.height() / 2);
    painter->translate(m_pos);
    painter->rotate(m_rotationSprite + 180);
    painter->drawPixmap(offsetPoint, m_sprite);
    painter->restore();
}


