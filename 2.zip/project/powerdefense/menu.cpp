#include "menu.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"mybutton.h"
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>


Menu::Menu(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(800,450);

    MyButton * back_btn=new MyButton(":/enter.jpg");
    back_btn->setParent(this);
    back_btn->move(10,10);
    connect(back_btn,&MyButton::clicked,this,[=](){
        emit chooseBack();
    });
}


void Menu::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pixmap(":/sub.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}
