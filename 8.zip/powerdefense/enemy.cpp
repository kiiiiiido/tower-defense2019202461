#include "enemy.h"
#include "waypoint.h"
#include "tower.h"
#include "utility.h"
#include "mainwindow.h"
#include <QPainter>
#include <QColor>
#include <QDebug>
#include <QMatrix>
#include <QVector2D>
#include <QtMath>

static const int Health_Bar_Width = 30;
const QSize Enemy::ms_fixedSize(75, 75);

Enemy::Enemy(WayPoint *startWayPoint, route *game, const QPixmap &sprite)
    : QObject(0)
    , m_pos(startWayPoint->pos())
    , m_sprite(sprite)
{
    m_maxHp = 40;
    m_currentHp = 40;
    m_active = false;
    m_walkingSpeed = 1.0;
    m_destinationWayPoint = startWayPoint->nextWayPoint();
    m_rotationSprite = 0.0;
    m_game = game;

}

Enemy::~Enemy(){
    m_attackedTowersList.clear();
    m_destinationWayPoint = NULL;
    m_game = NULL;
}

void Enemy::draw(QPainter *painter) const{
    if (!m_active)
        return;

    painter->save();

    QPoint healthBarPoint = m_pos + QPoint(0, -ms_fixedSize.height()/2 - 10);
    painter->setPen(Qt::NoPen);
    painter->setBrush(Qt::red);
    QRect healthBarBackRect(healthBarPoint, QSize(Health_Bar_Width, 5));
    painter->drawRect(healthBarBackRect);

    painter->setBrush(Qt::green);
    QRect healthBarRect(healthBarPoint, QSize((double)m_currentHp / m_maxHp * Health_Bar_Width, 5));
    painter->drawRect(healthBarRect);


    static const QPoint offsetPoint(-ms_fixedSize.width() / 2, -ms_fixedSize.height() / 2);
    painter->translate(m_pos);
    painter->rotate(m_rotationSprite);
    painter->drawPixmap(offsetPoint, m_sprite);

    painter->restore();
}

void Enemy::move(){
    if (!m_active)
        return;
    if (collisionWithCircle(m_pos, 1, m_destinationWayPoint->pos(), 1))
    {

        if (m_destinationWayPoint->nextWayPoint())
        {
            m_pos = m_destinationWayPoint->pos();
            m_destinationWayPoint = m_destinationWayPoint->nextWayPoint();
        }
        else
        {

            m_game->getHpDamage(damage);
            m_game->removedEnemy(this);
            return;
        }
    }
    QPoint targetPoint = m_destinationWayPoint->pos();

    double movementSpeed = m_walkingSpeed;
    QVector2D normalized(targetPoint - m_pos);
    normalized.normalize();
    m_pos = m_pos + 1.2*normalized.toPoint() * movementSpeed;
}

void Enemy::doActivate()
{
    m_active = true;
}

QPoint Enemy::pos() const{
    return m_pos;
}


bossEnemy::bossEnemy(WayPoint *startWayPoint, route *game, const QPixmap &sprite)
    :Enemy(startWayPoint, game,sprite)
{

    this->m_maxHp = 100;
    this->m_currentHp = 100;
    this->m_walkingSpeed=3.0;
    this->m_rotationSprite = 0.0;
    this->m_pos=startWayPoint->pos();
    this->m_destinationWayPoint=startWayPoint->nextWayPoint();
}

