#ifndef ROUTE_H
#define ROUTE_H
#include"towerposition.h"
#include"tower.h"
#include"enemy.h"
#include"waypoint.h"
#include<stdlib.h>
#include <QMainWindow>
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>
#include<QMouseEvent>

class TowerPosition;
class Tower;
class WayPoint;
class Enemy;

class route : public QMainWindow
{
    Q_OBJECT
public:
    explicit route(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);

    void getHpDamage(int damage);
    void removedEnemy(Enemy *enemy);
    bool loadWave();
    int						m_waves;
    bool					m_gameEnded;
    bool					m_gameWin;

    void updateMap();

private:
    void loadTowerPositions();
    void addWayPoints();

    QList<TowerPosition>	m_towerPositionsList;
    QList<Tower *> m_towersList;
    QList<WayPoint *> m_wayPointsList;
    QList<Enemy *> m_enemyList;

    bool canBuyTower() const;

protected:
    void mousePressEvent(QMouseEvent *);

signals:
    void routeBack();


};


#endif // ROUTE_H
