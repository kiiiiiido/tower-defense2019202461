#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPainter>
#include<QPixmap>
#include<QTimer>
#include<QPaintEvent>
#include<QPushButton>
#include"mybutton.h"
#include"menu.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setFixedSize(960, 540);
    MyButton * btn=new MyButton(":/start.jpg");
    btn->setParent(this);
    btn->move(0,0);
    Menu * scene1 = new Menu;
    connect(btn,&QPushButton::clicked,this,[=](){
        this->close();
        scene1->show();
    });

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pixmap(":/start.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}















