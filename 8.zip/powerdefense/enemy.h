#ifndef ENEMY_H
#define ENEMY_H

#include <QObject>
#include <QPoint>
#include <QSize>
#include <QPixmap>
#include <route.h>
class WayPoint;
class QPainter;
class MainWindow;
class Tower;
class route;



class Enemy : public QObject{
    Q_OBJECT
public:
    Enemy(WayPoint *startWayPoint, route *game, const QPixmap &sprite = QPixmap(":/bug.png"));
    virtual ~Enemy();
    void draw(QPainter *painter) const;
    void move();
    QPoint pos() const;

    bool            m_active;
    int             damage;
    int				m_maxHp;
    int				m_currentHp;

    double           m_walkingSpeed;
    qreal			m_rotationSprite;

    QPoint			m_pos;
    QPixmap         m_spirate;
    WayPoint *		m_destinationWayPoint;
    route *        m_game;

    QList<Tower *>	m_attackedTowersList;
    const QPixmap	m_sprite;
    static const QSize ms_fixedSize;

public slots:
    void doActivate();

};

class bossEnemy:public Enemy{
    Q_OBJECT
public:
    bossEnemy(WayPoint *startWayPoint, route *game, const QPixmap &sprite = QPixmap(":/monster.png"));
};



#endif // ENEMY_H
