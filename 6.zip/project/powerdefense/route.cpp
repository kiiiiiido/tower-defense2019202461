#include "route.h"
#include"menu.h"
#include"tower.h"
#include"towerposition.h"
#include "ui_mainwindow.h"
#include"mybutton.h"
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>
class route;

route::route(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(960,540);

     loadTowerPositions();

    MyButton * back_btn=new MyButton(":/compass.png");
    back_btn->setParent(this);
    back_btn->move(800,40);
    connect(back_btn,&MyButton::clicked,this,[=](){
        emit routeBack();
    });
}

void route::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pixmap(":/withTower.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);

    foreach (Tower *tower, m_towersList)
        tower->draw(&painter);

}


void route::loadTowerPositions()
{
    QPoint pos[] =
    {
        QPoint(252, 10),
        QPoint(352, 10),
        QPoint(452, 10),


        QPoint(252, 140),
        QPoint(355, 140),
        QPoint(455, 140),

        QPoint(750, 135),
        QPoint(750, 230),
        QPoint(750, 320),

        QPoint(535, 320),
        QPoint(437, 320),
        QPoint(342, 320),
    };
    int len	= sizeof(pos) / sizeof(pos[0]);
    for (int i = 0; i < len; ++i)
            m_towerPositionsList.push_back(pos[i]);

}

void route::mousePressEvent(QMouseEvent *event)
{
    QPoint pressPos = event->pos();
    auto it = m_towerPositionsList.begin();
    while (it != m_towerPositionsList.end())
    {
        if (canBuyTower() && it->containPoint(pressPos) && !it->hasTower())
        {
            it->setHasTower();
            Tower *tower = new Tower(it->centerPos(), this);
            m_towersList.push_back(tower);
            update();
            break;
        }

        ++it;
    }
}

bool route::canBuyTower() const
{
    return true;

}

