#include "set.h"
#include "menu.h"
#include "ui_mainwindow.h"
#include"mybutton.h"
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>

set::set(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(960,540);

    MyButton * back_btn=new MyButton(":/attacter.png");
    back_btn->setParent(this);
    back_btn->move(750,320);
    connect(back_btn,&MyButton::clicked,this,[=](){
        emit setBack();
    });

}


void set::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pixmap(":/withTower.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}
