#ifndef ROUTE_H
#define ROUTE_H
#include"towerposition.h"
#include"tower.h"
#include<stdlib.h>
#include <QMainWindow>
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>
#include<QMouseEvent>

class TowerPosition;
class Tower;

class route : public QMainWindow
{
    Q_OBJECT
public:
    explicit route(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);


private:
    void loadTowerPositions();

    QList<TowerPosition>	m_towerPositionsList;
    QList<Tower *> m_towersList;

    bool canBuyTower() const;

protected:
    void mousePressEvent(QMouseEvent *);

signals:
    void routeBack();


};

#endif // ROUTE_H
